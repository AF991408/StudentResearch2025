import torch
import torch.nn as nn
import torch.nn.functional as F

class DKVMNHeadGroup(nn.Module):
    def __init__(self, memory_size, memory_state_dim, control_dim=None, is_write=False, name="DKVMNHeadGroup"):
        """
        Parameters:
            memory_size:        int, number of memory slots
            memory_state_dim:   int, dimension of each memory slot (key or value)
            control_dim:        int, dimension of the control input (if None, assumed equal to memory_state_dim)
            is_write:           bool, if True, this head will perform write operations
            name:               string, name of the head
        """
        super(DKVMNHeadGroup, self).__init__()
        self.name = name
        self.memory_size = memory_size
        self.memory_state_dim = memory_state_dim
        self.control_dim = control_dim if control_dim is not None else memory_state_dim
        self.is_write = is_write

        # For write heads, define linear layers for erase and add signals.
        if self.is_write:
            self.erase_linear = nn.Linear(self.control_dim, self.memory_state_dim)
            self.add_linear = nn.Linear(self.control_dim, self.memory_state_dim)

    def addressing(self, control_input, memory):
        """
        Computes the correlation weight between the control input and memory.
        Parameters:
            control_input:   Tensor of shape (batch_size, control_dim)
            memory:          Tensor of shape (memory_size, memory_state_dim)
                             (typically a fixed key memory)
        Returns:
            correlation_weight: Tensor of shape (batch_size, memory_size)
        """
        # Compute similarity score: equivalent to a fully-connected layer with weight=memory and no bias.
        similarity_score = torch.matmul(control_input, memory.t())
        correlation_weight = F.softmax(similarity_score, dim=-1)
        return correlation_weight

    def read(self, memory, control_input=None, read_weight=None):
        """
        Reads from memory.
        Parameters:
            memory:         Tensor of shape (batch_size, memory_size, memory_state_dim)
                            or (memory_size, memory_state_dim) to be broadcast over batch.
            control_input:  Tensor of shape (batch_size, control_dim); used if read_weight is not provided.
            read_weight:    Tensor of shape (batch_size, memory_size). If None, computed via addressing().
        Returns:
            read_content:   Tensor of shape (batch_size, memory_state_dim)
        """
        # If memory is provided without batch dimension, expand it.
        if memory.dim() == 2:
            batch_size = control_input.size(0)
            memory = memory.unsqueeze(0).expand(batch_size, -1, -1)
        if read_weight is None:
            read_weight = self.addressing(control_input, memory[:, 0, :])
            # Note: when using addressing here, we assume the same memory is used for both addressing and reading.
        # Reshape write_weight to perform batch multiplication.
        read_weight = read_weight.view(-1, 1, self.memory_size)
        # Perform batched matrix multiplication.
        read_content = torch.bmm(read_weight, memory).view(-1, self.memory_state_dim)
        return read_content

    def write(self, control_input, memory, write_weight=None):
        """
        Writes to memory.
        Parameters:
            control_input:  Tensor of shape (batch_size, control_dim)
            memory:         Tensor of shape (batch_size, memory_size, memory_state_dim)
            write_weight:   Tensor of shape (batch_size, memory_size); if None, computed via addressing().
        Returns:
            new_memory:     Tensor of shape (batch_size, memory_size, memory_state_dim)
        """
        assert self.is_write, f"{self.name} is not a write head."
        if write_weight is None:
            write_weight = self.addressing(control_input, memory[:, 0, :])
        # Compute erase signal: (batch_size, memory_state_dim)
        erase_signal = torch.sigmoid(self.erase_linear(control_input))
        # Compute add signal: (batch_size, memory_state_dim)
        add_signal = torch.tanh(self.add_linear(control_input))
        # Reshape for batch matrix multiplication.
        write_weight_reshaped = write_weight.view(-1, self.memory_size, 1)
        erase_signal_reshaped = erase_signal.view(-1, 1, self.memory_state_dim)
        add_signal_reshaped = add_signal.view(-1, 1, self.memory_state_dim)
        # Compute erase multiplier: (batch_size, memory_size, memory_state_dim)
        erase_mult = 1 - torch.bmm(write_weight_reshaped, erase_signal_reshaped)
        # Compute addition signal.
        aggre_add_signal = torch.bmm(write_weight_reshaped, add_signal_reshaped)
        new_memory = memory * erase_mult + aggre_add_signal
        return new_memory

class DKVMN(nn.Module):
    def __init__(self, memory_size, memory_key_state_dim, memory_value_state_dim,
                 init_memory_key=None, init_memory_value=None, name="DKVMN"):
        """
        Parameters:
            memory_size:             int, number of memory slots
            memory_key_state_dim:    int, dimension of each key slot
            memory_value_state_dim:  int, dimension of each value slot
            init_memory_key:         Optional Tensor of shape (memory_size, memory_key_state_dim)
            init_memory_value:       Optional Tensor of shape (memory_size, memory_value_state_dim)
            name:                    string, name of the DKVMN instance
        """
        super(DKVMN, self).__init__()
        self.name = name
        self.memory_size = memory_size
        self.memory_key_state_dim = memory_key_state_dim
        self.memory_value_state_dim = memory_value_state_dim

        # Initialize memory key and value. If not provided, they are created as parameters.
        if init_memory_key is None:
            self.memory_key = nn.Parameter(torch.Tensor(memory_size, memory_key_state_dim))
        else:
            self.memory_key = init_memory_key
        if init_memory_value is None:
            self.memory_value = nn.Parameter(torch.Tensor(memory_size, memory_value_state_dim))
        else:
            self.memory_value = init_memory_value

        # Create the head groups.
        self.key_head = DKVMNHeadGroup(memory_size=memory_size,
                                       memory_state_dim=memory_key_state_dim,
                                       control_dim=memory_key_state_dim,
                                       is_write=False,
                                       name=self.name + "->key_head")
        self.value_head = DKVMNHeadGroup(memory_size=memory_size,
                                         memory_state_dim=memory_value_state_dim,
                                         control_dim=memory_value_state_dim,
                                         is_write=True,
                                         name=self.name + "->value_head")

    def attention(self, control_input):
        """
        Computes attention (correlation weights) over the key memory.
        Parameters:
            control_input: Tensor of shape (batch_size, memory_key_state_dim)
        Returns:
            correlation_weight: Tensor of shape (batch_size, memory_size)
        """
        correlation_weight = self.key_head.addressing(control_input, self.memory_key)
        return correlation_weight

    def read(self, read_weight, batch_memory_value=None):
        """
        Reads content from the value memory.
        Parameters:
            read_weight:         Tensor of shape (batch_size, memory_size)
            batch_memory_value:  Optional Tensor of shape (batch_size, memory_size, memory_value_state_dim).
                                 If not provided, self.memory_value is expanded across the batch.
        Returns:
            read_content:        Tensor of shape (batch_size, memory_value_state_dim)
        """
        if batch_memory_value is None:
            batch_size = read_weight.size(0)
            memory = self.memory_value.unsqueeze(0).expand(batch_size, -1, -1)
        else:
            memory = batch_memory_value
        read_content = self.value_head.read(memory, read_weight=read_weight)
        return read_content

    def write(self, write_weight, control_input, batch_memory_value=None):
        """
        Updates the value memory with new information.
        Parameters:
            write_weight:        Tensor of shape (batch_size, memory_size)
            control_input:       Tensor of shape (batch_size, memory_value_state_dim)
            batch_memory_value:  Optional Tensor of shape (batch_size, memory_size, memory_value_state_dim).
                                 If not provided, self.memory_value is expanded across the batch.
        Returns:
            new_memory:          Tensor of shape (batch_size, memory_size, memory_value_state_dim)
        """
        if batch_memory_value is None:
            batch_size = write_weight.size(0)
            memory = self.memory_value.unsqueeze(0).expand(batch_size, -1, -1)
        else:
            memory = batch_memory_value
        new_memory = self.value_head.write(control_input, memory, write_weight=write_weight)
        return new_memory
