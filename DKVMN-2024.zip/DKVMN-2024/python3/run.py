import numpy as np
import math
import torch
import torch.nn.functional as F
from sklearn import metrics

def norm_clipping(model, threshold):
    total_norm = 0.0
    for p in model.parameters():
        if p.grad is not None:
            total_norm += p.grad.data.norm(2).item() ** 2
    total_norm = total_norm ** 0.5
    if total_norm > threshold:
        scale = threshold / total_norm
        for p in model.parameters():
            if p.grad is not None:
                p.grad.data.mul_(scale)
    return total_norm

def binaryEntropy(target, pred, mod="avg"):
    loss = target * np.log(np.maximum(1e-10, pred)) + (1.0 - target) * np.log(np.maximum(1e-10, 1.0 - pred))
    if mod == 'avg':
        return -np.average(loss)
    elif mod == 'sum':
        return -loss.sum()
    else:
        assert False

def compute_auc(all_target, all_pred):
    return metrics.roc_auc_score(all_target, all_pred)

def compute_accuracy(all_target, all_pred):
    all_pred = np.where(all_pred > 0.5, 1.0, 0.0)
    return metrics.accuracy_score(all_target, all_pred)

def train(net, params, q_data, qa_data, label):
    # Assume q_data and qa_data are NumPy arrays of shape (num_samples, seqlen)
    N = int(math.floor(len(q_data) / params.batch_size))
    # Shuffle the data along the sample axis
    shuffled_ind = np.arange(q_data.shape[0])
    np.random.shuffle(shuffled_ind)
    q_data = q_data[shuffled_ind]
    qa_data = qa_data[shuffled_ind]

    pred_list = []
    target_list = []

    if params.show:
        from utils import ProgressBar
        bar = ProgressBar(label, max=N)

    for idx in range(N):
        if params.show:
            bar.next()

        start = idx * params.batch_size
        end = (idx + 1) * params.batch_size
        # In PyTorch we expect (batch_size, seqlen)
        q_one_seq = q_data[start:end, :]   
        qa_one_seq = qa_data[start:end, :]

        # Compute target: (qa - 1) / n_question, then floor to yield binary values
        target = np.floor((qa_one_seq - 1) / params.n_question)

        # Convert to torch tensors. Embedding lookups require Long type.
        input_q = torch.tensor(q_one_seq, device=params.ctx, dtype=torch.long)
        input_qa = torch.tensor(qa_one_seq, device=params.ctx, dtype=torch.long)
        target_tensor = torch.tensor(target, device=params.ctx, dtype=torch.float32)

        # Forward pass; our PyTorch model returns predictions as a flattened tensor
        net.train()
        pred = net(input_q, input_qa, target_tensor)  # shape: (batch_size * seqlen,)

        # Create a mask to ignore padded values (where target == -1)
        target_flat = target_tensor.view(-1)
        mask = (target_flat != -1.0)
        pred_nonpad = pred[mask]
        target_nonpad = target_flat[mask]

        # Compute binary cross-entropy loss on non-padding elements
        loss = F.binary_cross_entropy(pred_nonpad, target_nonpad)

        net.zero_grad()
        loss.backward()
        norm_clipping(net, params.maxgradnorm)
        params.optimizer.step()

        # Collect predictions and targets for evaluation
        pred_np = pred.detach().cpu().numpy()
        target_np = target_flat.detach().cpu().numpy()
        valid_idx = np.flatnonzero(target_np != -1.0)
        pred_list.append(pred_np[valid_idx])
        target_list.append(target_np[valid_idx])

    if params.show:
        bar.finish()

    all_pred = np.concatenate(pred_list, axis=0)
    all_target = np.concatenate(target_list, axis=0)

    loss_val = binaryEntropy(all_target, all_pred)
    print("all_target", all_target)
    print("all_pred", all_pred)
    auc = compute_auc(all_target, all_pred)
    accuracy = compute_accuracy(all_target, all_pred)

    return loss_val, accuracy, auc

def test(net, params, q_data, qa_data, label):
    # Assume q_data and qa_data are NumPy arrays of shape (num_samples, seqlen)
    N = int(math.ceil(float(len(q_data)) / float(params.batch_size)))
    seq_num = q_data.shape[0]
    pred_list = []
    target_list = []
    if params.show:
        from utils import ProgressBar
        bar = ProgressBar(label, max=N)

    for idx in range(N):
        if params.show:
            bar.next()

        # Use wrapping if the last batch is smaller than batch_size
        inds = np.arange(idx * params.batch_size, (idx + 1) * params.batch_size) % seq_num
        q_one_seq = q_data[inds, :]  
        qa_one_seq = qa_data[inds, :]
        target = np.floor((qa_one_seq - 1) / params.n_question)

        input_q = torch.tensor(q_one_seq, device=params.ctx, dtype=torch.long)
        input_qa = torch.tensor(qa_one_seq, device=params.ctx, dtype=torch.long)
        target_tensor = torch.tensor(target, device=params.ctx, dtype=torch.float32)

        net.eval()
        with torch.no_grad():
            pred = net(input_q, input_qa, target_tensor)  # shape: (batch_size * seqlen,)
        target_flat = target_tensor.view(-1)
        pred_np = pred.cpu().numpy()
        target_np = target_flat.cpu().numpy()
        valid_idx = np.flatnonzero(target_np != -1.0)
        pred_list.append(pred_np[valid_idx])
        target_list.append(target_np[valid_idx])

    if params.show:
        bar.finish()
    all_pred = np.concatenate(pred_list, axis=0)
    all_target = np.concatenate(target_list, axis=0)

    loss_val = binaryEntropy(all_target, all_pred)
    auc = compute_auc(all_target, all_pred)
    accuracy = compute_accuracy(all_target, all_pred)

    return loss_val, accuracy, auc
