import torch
import torch.nn as nn
import torch.nn.functional as F
import ast
from memory import DKVMN

def safe_eval(expr):
    if isinstance(expr, str):
        return ast.literal_eval(expr)
    else:
        return expr

# Custom autograd Function for masked logistic regression output.
class LogisticRegressionMaskOutputFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx, input, label, ignore_label):
        # Compute sigmoid activation.
        output = torch.sigmoid(input)
        ctx.save_for_backward(output, label)
        ctx.ignore_label = ignore_label
        return output

    @staticmethod
    def backward(ctx, grad_output):
        output, label = ctx.saved_tensors
        # Create a mask where label != ignore_label.
        mask = (label != ctx.ignore_label).float()
        grad_input = grad_output * (output - label) * mask
        # No gradients for label or ignore_label.
        return grad_input, None, None

def logistic_regression_mask_output(data, label, ignore_label, name=None):
    # data and label should be flattened tensors.
    return LogisticRegressionMaskOutputFunction.apply(data, label, ignore_label)

class MODEL(nn.Module):
    def __init__(self, n_question, seqlen, batch_size,
                 q_embed_dim, qa_embed_dim,
                 memory_size, memory_key_state_dim, memory_value_state_dim,
                 final_fc_dim, name="KT"):
        super(MODEL, self).__init__()
        self.n_question = n_question
        self.seqlen = seqlen
        self.batch_size = batch_size
        self.q_embed_dim = q_embed_dim
        self.qa_embed_dim = qa_embed_dim
        self.memory_size = memory_size
        self.memory_key_state_dim = memory_key_state_dim
        self.memory_value_state_dim = memory_value_state_dim
        self.final_fc_dim = final_fc_dim
        self.name = name

        # Embedding layers.
        self.q_embed = nn.Embedding(n_question + 1, q_embed_dim)
        self.qa_embed = nn.Embedding(n_question * 2 + 1, qa_embed_dim)

        # Initialize DKVMN memory. (DKVMN is assumed to be a PyTorch module.)
        # Here we let DKVMN initialize its own memory parameters if not provided.
        self.mem = DKVMN(memory_size=memory_size,
                         memory_key_state_dim=memory_key_state_dim,
                         memory_value_state_dim=memory_value_state_dim,
                         init_memory_key=None,
                         init_memory_value=None,
                         name="DKVMN")

        # Fully connected layers.
        self.input_fc = nn.Linear(q_embed_dim, 50)
        self.read_content_fc = nn.Linear(memory_value_state_dim + 50, final_fc_dim)
        self.final_fc = nn.Linear(final_fc_dim, 1)

    def forward(self, q_data, qa_data, target):
        """
        Parameters:
            q_data:   Tensor of shape (batch_size, seqlen) with question indices.
            qa_data:  Tensor of shape (batch_size, seqlen) with combined question/answer indices.
            target:   Tensor of shape (batch_size, seqlen) with target values.
        Returns:
            pred_prob: Tensor of shape (batch_size * seqlen,) containing the masked sigmoid outputs.
        """
        batch_size = q_data.size(0)
        seqlen = self.seqlen

        # Lookup embeddings.
        q_embed_data = self.q_embed(q_data)    # (batch_size, seqlen, q_embed_dim)
        qa_embed_data = self.qa_embed(qa_data)   # (batch_size, seqlen, qa_embed_dim)

        # Initialize current memory value from DKVMN's value memory.
        # Expand the memory (of shape (memory_size, memory_value_state_dim)) to a batch.
        current_memory_value = self.mem.memory_value.unsqueeze(0).expand(batch_size, -1, -1)

        value_read_content_list = []
        input_embed_list = []

        # Process the sequence one time step at a time.
        for i in range(seqlen):
            # Extract embeddings at time step i.
            q = q_embed_data[:, i, :]      # (batch_size, q_embed_dim)
            qa = qa_embed_data[:, i, :]    # (batch_size, qa_embed_dim)

            # Compute attention (correlation weight) using the memory key.
            correlation_weight = self.mem.attention(q)  # (batch_size, memory_size)

            # Read from the memory value using the computed correlation weight.
            read_content = self.mem.read(correlation_weight, batch_memory_value=current_memory_value)
            value_read_content_list.append(read_content)
            input_embed_list.append(q)

            # Write to the memory using the current qa embedding and update memory.
            new_memory_value = self.mem.write(correlation_weight, qa, batch_memory_value=current_memory_value)
            current_memory_value = new_memory_value

        # Concatenate outputs from all time steps.
        # Each list element has shape (batch_size, feature_dim); we stack along the time axis.
        # Then reshape to merge batch and time dimensions.
        all_read_value_content = torch.cat(value_read_content_list, dim=0)  # (batch_size * seqlen, memory_value_state_dim)
        input_embed_content = torch.cat(input_embed_list, dim=0)              # (batch_size * seqlen, q_embed_dim)

        # Process the concatenated question embeddings.
        input_embed_content = torch.tanh(self.input_fc(input_embed_content))  # (batch_size * seqlen, 50)

        # Concatenate the read content and processed input embeddings along the feature dimension.
        combined_features = torch.cat([all_read_value_content, input_embed_content], dim=1)  # (batch_size * seqlen, memory_value_state_dim + 50)
        read_content_embed = torch.tanh(self.read_content_fc(combined_features))            # (batch_size * seqlen, final_fc_dim)

        # Final fully connected layer.
        pred = self.final_fc(read_content_embed)  # (batch_size * seqlen, 1)
        pred = pred.view(-1)  # Flatten to shape (batch_size * seqlen,)

        # Flatten the target to match the prediction.
        target_flat = target.view(-1)

        # Apply the custom logistic regression mask output.
        pred_prob = logistic_regression_mask_output(pred, target_flat, -1.)
        return pred_prob
