import sys
import os
import logging
import argparse
import torch
import numpy as np

from load_data import DATA
from model import MODEL
from run import train, test

root = logging.getLogger()
root.setLevel(logging.DEBUG)

ch = logging.StreamHandler(sys.stdout)
ch.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(formatter)
root.addHandler(ch)

def find_file(dir_name, best_epoch):
    for root_dir, subdirs, files in os.walk(dir_name):
        for sub in subdirs:
            if sub[0:len(best_epoch)] == best_epoch and sub[len(best_epoch)] == "_":
                return sub

def load_params(prefix, epoch):
    # Load a checkpoint saved as a .pth file
    save_dict = torch.load(f'{prefix}-{epoch:04d}.pth', map_location='cpu')
    arg_params = {}
    aux_params = {}
    # Assuming the saved state dict has keys formatted as 'arg:<name>' and 'aux:<name>'
    for k, v in save_dict.items():
        tp, name = k.split(':', 1)
        if tp == 'arg':
            arg_params[name] = v
        elif tp == 'aux':
            aux_params[name] = v
    return arg_params, aux_params

def train_one_dataset(params, file_name, train_q_data, train_qa_data, valid_q_data, valid_qa_data):
    ### ================================== model initialization ==================================
    g_model = MODEL(n_question=params.n_question,
                    seqlen=params.seqlen,
                    batch_size=params.batch_size,
                    q_embed_dim=params.q_embed_dim,
                    qa_embed_dim=params.qa_embed_dim,
                    memory_size=params.memory_size,
                    memory_key_state_dim=params.memory_key_state_dim,
                    memory_value_state_dim=params.memory_value_state_dim,
                    final_fc_dim=params.final_fc_dim)
    g_model = g_model.to(params.ctx)

    # Initialize model parameters using a normal initializer
    def init_weights(m):
        if isinstance(m, torch.nn.Linear):
            torch.nn.init.normal_(m.weight, std=params.init_std)
            if m.bias is not None:
                torch.nn.init.constant_(m.bias, 0)
    g_model.apply(init_weights)

    # Set up optimizer and learning rate scheduler
    optimizer = torch.optim.SGD(g_model.parameters(), lr=params.lr, momentum=params.momentum)
    # Step scheduler: every step_size iterations, the learning rate is multiplied by gamma (0.667)
    step_size = int(20 * (train_q_data.shape[0] / params.batch_size))
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=step_size, gamma=0.667)

    # Print parameter names and shapes
    for name, param in g_model.named_parameters():
        print(name, list(param.size()))
    print("\n")

    ### ================================== start training ==================================
    all_train_loss = {}
    all_train_accuracy = {}
    all_train_auc = {}
    all_valid_loss = {}
    all_valid_accuracy = {}
    all_valid_auc = {}
    best_valid_auc = 0

    for idx in range(params.max_iter):
        # The train function is expected to perform one epoch of training and return loss/accuracy/auc
        train_loss, train_accuracy, train_auc = train(g_model, params, optimizer, scheduler, train_q_data, train_qa_data, label='Train')
        valid_loss, valid_accuracy, valid_auc = test(g_model, params, valid_q_data, valid_qa_data, label='Valid')

        print('epoch', idx + 1)
        print("valid_auc\t", valid_auc, "\ttrain_auc\t", train_auc)
        print("valid_accuracy\t", valid_accuracy, "\ttrain_accuracy\t", train_accuracy)
        print("valid_loss\t", valid_loss, "\ttrain_loss\t", train_loss)

        if not os.path.isdir('model'):
            os.makedirs('model')
        model_dir = os.path.join('model', params.save)
        if not os.path.isdir(model_dir):
            os.makedirs(model_dir)

        all_valid_auc[idx + 1] = valid_auc
        all_train_auc[idx + 1] = train_auc
        all_valid_loss[idx + 1] = valid_loss
        all_train_loss[idx + 1] = train_loss
        all_valid_accuracy[idx + 1] = valid_accuracy
        all_train_accuracy[idx + 1] = train_accuracy

        # Save the checkpoint if we achieved a new best validation AUC
        if valid_auc > best_valid_auc:
            best_valid_auc = valid_auc
            best_epoch = idx + 1
            # Save model state_dict; here we mimic the original naming scheme (epoch is fixed at 100)
            torch.save(g_model.state_dict(), os.path.join(model_dir, f"{file_name}-{100:04d}.pth"))

    result_dir = os.path.join('result', params.save)
    if not os.path.isdir('result'):
        os.makedirs('result')
    if not os.path.isdir(result_dir):
        os.makedirs(result_dir)
    with open(os.path.join(result_dir, file_name), 'w') as f_save_log:
        f_save_log.write("valid_auc:\n" + str(all_valid_auc) + "\n\n")
        f_save_log.write("train_auc:\n" + str(all_train_auc) + "\n\n")
        f_save_log.write("valid_loss:\n" + str(all_valid_loss) + "\n\n")
        f_save_log.write("train_loss:\n" + str(all_train_loss) + "\n\n")
        f_save_log.write("valid_accuracy:\n" + str(all_valid_accuracy) + "\n\n")
        f_save_log.write("train_accuracy:\n" + str(all_train_accuracy) + "\n\n")
    return best_epoch

def test_one_dataset(params, file_name, test_q_data, test_qa_data):
    print("\n\nStart testing ......................")
    g_model = MODEL(n_question=params.n_question,
                    seqlen=params.seqlen,
                    batch_size=params.batch_size,
                    q_embed_dim=params.q_embed_dim,
                    qa_embed_dim=params.qa_embed_dim,
                    memory_size=params.memory_size,
                    memory_key_state_dim=params.memory_key_state_dim,
                    memory_value_state_dim=params.memory_value_state_dim,
                    final_fc_dim=params.final_fc_dim)
    g_model = g_model.to(params.ctx)
    # Load checkpoint; assumes state_dict keys are saved with the 'arg:' prefix as in load_params
    arg_params, aux_params = load_params(prefix=os.path.join('model', params.load, file_name), epoch=100)
    # For simplicity, we load only the argument parameters into the model
    g_model.load_state_dict(arg_params)
    test_loss, test_accuracy, test_auc = test(g_model, params, test_q_data, test_qa_data, label='Test')
    log_info = "\ntest_auc:\t{}\ntest_accuracy:\t{}\ntest_loss:\t{}\n".format(test_auc, test_accuracy, test_loss)
    print(log_info)
    result_path = os.path.join('result', params.save, file_name)
    with open(result_path, 'a') as f_save_log:
        f_save_log.write(log_info)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Script to test KVMN using PyTorch.')
    parser.add_argument('--gpus', type=str, default='0', help='the GPUs to be used, e.g. "0,1,2,3"')
    parser.add_argument('--max_iter', type=int, default=100, help='number of iterations')
    parser.add_argument('--test', type=bool, default=False, help='enable testing')
    parser.add_argument('--train_test', type=bool, default=True, help='enable testing')
    parser.add_argument('--show', type=bool, default=True, help='print progress')
    parser.add_argument('--seedNum', type=int, default=1024, help='the random seed')

    dataset = "assist2009_updated"  # synthetic / assist2009_updated / assist2015 / KDDal0506 / STATICS

    if dataset == "synthetic":
        parser.add_argument('--batch_size', type=int, default=32, help='the batch size')
        parser.add_argument('--q_embed_dim', type=int, default=10, help='question embedding dimensions')
        parser.add_argument('--qa_embed_dim', type=int, default=10, help='answer and question embedding dimensions')
        parser.add_argument('--memory_size', type=int, default=5, help='memory size')
        parser.add_argument('--init_std', type=float, default=0.1, help='weight initialization std')
        parser.add_argument('--init_lr', type=float, default=0.05, help='initial learning rate')
        parser.add_argument('--final_lr', type=float, default=1E-5, help='minimum learning rate')
        parser.add_argument('--momentum', type=float, default=0.9, help='momentum rate')
        parser.add_argument('--maxgradnorm', type=float, default=50.0, help='maximum gradient norm')
        parser.add_argument('--final_fc_dim', type=float, default=50, help='hidden state dim for final fc layer')
        parser.add_argument('--n_question', type=int, default=50, help='the number of unique questions in the dataset')
        parser.add_argument('--seqlen', type=int, default=50, help='the allowed maximum length of a sequence')
        parser.add_argument('--data_dir', type=str, default='../../data/synthetic', help='data directory')
        parser.add_argument('--data_name', type=str, default='naive_c5_q50_s4000_v1', help='dataset name')
        parser.add_argument('--load', type=str, default='synthetic/v1', help='model file to load')
        parser.add_argument('--save', type=str, default='synthetic/v1', help='path to save model')
    if dataset == "assist2009_updated":
        parser.add_argument('--batch_size', type=int, default=32, help='the batch size')
        parser.add_argument('--q_embed_dim', type=int, default=50, help='question embedding dimensions')
        parser.add_argument('--qa_embed_dim', type=int, default=200, help='answer and question embedding dimensions')
        parser.add_argument('--memory_size', type=int, default=20, help='memory size')
        parser.add_argument('--init_std', type=float, default=0.1, help='weight initialization std')
        parser.add_argument('--init_lr', type=float, default=0.05, help='initial learning rate')
        parser.add_argument('--final_lr', type=float, default=1E-5, help='minimum learning rate')
        parser.add_argument('--momentum', type=float, default=0.9, help='momentum rate')
        parser.add_argument('--maxgradnorm', type=float, default=50.0, help='maximum gradient norm')
        parser.add_argument('--final_fc_dim', type=float, default=50, help='hidden state dim for final fc layer')
        parser.add_argument('--n_question', type=int, default=110, help='the number of unique questions in the dataset')
        parser.add_argument('--seqlen', type=int, default=200, help='the allowed maximum length of a sequence')
        parser.add_argument('--data_dir', type=str, default='C:/Users/alexf/Documents/CSC/AI Assisted Learning/previous_model/DKVMN-2024/data/assist2009_updated', help='data directory')
        parser.add_argument('--data_name', type=str, default='assist2009_updated', help='dataset name')
        parser.add_argument('--load', type=str, default='assist2009_updated', help='model file to load')
        parser.add_argument('--save', type=str, default='assist2009_updated', help='path to save model')
    elif dataset == "assist2015":
        parser.add_argument('--batch_size', type=int, default=50, help='the batch size')
        parser.add_argument('--q_embed_dim', type=int, default=50, help='question embedding dimensions')
        parser.add_argument('--qa_embed_dim', type=int, default=100, help='answer and question embedding dimensions')
        parser.add_argument('--memory_size', type=int, default=20, help='memory size')
        parser.add_argument('--init_std', type=float, default=0.1, help='weight initialization std')
        parser.add_argument('--init_lr', type=float, default=0.1, help='initial learning rate')
        parser.add_argument('--final_lr', type=float, default=1E-5, help='minimum learning rate')
        parser.add_argument('--momentum', type=float, default=0.9, help='momentum rate')
        parser.add_argument('--maxgradnorm', type=float, default=50.0, help='maximum gradient norm')
        parser.add_argument('--final_fc_dim', type=float, default=50, help='hidden state dim for final fc layer')
        parser.add_argument('--n_question', type=int, default=100, help='the number of unique questions in the dataset')
        parser.add_argument('--seqlen', type=int, default=200, help='the allowed maximum length of a sequence')
        parser.add_argument('--data_dir', type=str, default='../../data/assist2015', help='data directory')
        parser.add_argument('--data_name', type=str, default='assist2015', help='dataset name')
        parser.add_argument('--load', type=str, default='assist2015', help='model file to load')
        parser.add_argument('--save', type=str, default='assist2015', help='path to save model')
    elif dataset == "STATICS":
        parser.add_argument('--batch_size', type=int, default=10, help='the batch size')
        parser.add_argument('--q_embed_dim', type=int, default=50, help='question embedding dimensions')
        parser.add_argument('--qa_embed_dim', type=int, default=100, help='answer and question embedding dimensions')
        parser.add_argument('--memory_size', type=int, default=50, help='memory size')
        parser.add_argument('--init_std', type=float, default=0.1, help='weight initialization std')
        parser.add_argument('--init_lr', type=float, default=0.01, help='initial learning rate')
        parser.add_argument('--final_lr', type=float, default=1E-5, help='minimum learning rate')
        parser.add_argument('--momentum', type=float, default=0.9, help='momentum rate')
        parser.add_argument('--maxgradnorm', type=float, default=50.0, help='maximum gradient norm')
        parser.add_argument('--final_fc_dim', type=float, default=50, help='hidden state dim for final fc layer')
        parser.add_argument('--n_question', type=int, default=1223, help='the number of unique questions in the dataset')
        parser.add_argument('--seqlen', type=int, default=200, help='the allowed maximum length of a sequence')
        parser.add_argument('--data_dir', type=str, default='../../data/STATICS', help='data directory')
        parser.add_argument('--data_name', type=str, default='STATICS', help='dataset name')
        parser.add_argument('--load', type=str, default='STATICS', help='model file to load')
        parser.add_argument('--save', type=str, default='STATICS', help='path to save model')

    params = parser.parse_args()
    params.lr = params.init_lr
    params.memory_key_state_dim = params.q_embed_dim
    params.memory_value_state_dim = params.qa_embed_dim
    params.dataset = dataset

    # Set device based on GPU argument
    if params.gpus is None or params.gpus == "":
        ctx = torch.device('cpu')
        print("Training with cpu ...")
    else:
        ctx = torch.device('cuda:' + params.gpus)
        print("Training with gpu(" + params.gpus + ") ...")
    params.ctx = ctx

    # Read data
    dat = DATA(n_question=params.n_question, seqlen=params.seqlen, separate_char=',')
    seedNum = params.seedNum
    np.random.seed(seedNum)
    if not params.test:
        params.memory_key_state_dim = params.q_embed_dim
        params.memory_value_state_dim = params.qa_embed_dim
        d = vars(params)
        for key in d:
            print('\t', key, '\t', d[key])
        file_name = 'b' + str(params.batch_size) + \
                    '_q' + str(params.q_embed_dim) + '_qa' + str(params.qa_embed_dim) + \
                    '_m' + str(params.memory_size) + '_std' + str(params.init_std) + \
                    '_lr' + str(params.init_lr) + '_gn' + str(params.maxgradnorm) + \
                    '_f' + str(params.final_fc_dim) + '_s' + str(seedNum)
        train_data_path = os.path.join(params.data_dir, params.data_name + "_train1.csv")
        valid_data_path = os.path.join(params.data_dir, params.data_name + "_valid1.csv")
        train_q_data, train_qa_data = dat.load_data(train_data_path)
        valid_q_data, valid_qa_data = dat.load_data(valid_data_path)
        print("\n")
        print("train_q_data.shape", train_q_data.shape, train_q_data)
        print("train_qa_data.shape", train_qa_data.shape, train_qa_data)
        print("valid_q_data.shape", valid_q_data.shape)
        print("valid_qa_data.shape", valid_qa_data.shape)
        print("\n")
        best_epoch = train_one_dataset(params, file_name, train_q_data, train_qa_data, valid_q_data, valid_qa_data)
        if params.train_test:
            test_data_path = os.path.join(params.data_dir, params.data_name + "_test.csv")
            test_q_data, test_qa_data = dat.load_data(test_data_path)
            test_one_dataset(params, file_name, test_q_data, test_qa_data)
    else:
        params.memory_key_state_dim = params.q_embed_dim
        params.memory_value_state_dim = params.qa_embed_dim
        test_data_path = os.path.join(params.data_dir, params.data_name + "_test.csv")
        test_q_data, test_qa_data = dat.load_data(test_data_path)
        file_name = 'b' + str(params.batch_size) + \
                    '_q' + str(params.q_embed_dim) + '_qa' + str(params.qa_embed_dim) + \
                    '_m' + str(params.memory_size) + '_std' + str(params.init_std) + \
                    '_lr' + str(params.init_lr) + '_gn' + str(params.maxgradnorm) + \
                    '_f' + str(params.final_fc_dim) + '_s' + str(seedNum)
        test_one_dataset(params, file_name, test_q_data, test_qa_data)
